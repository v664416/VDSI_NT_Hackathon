﻿var NTLibrary = new NTLibrary.LibraryMgmt.LibraryFunctions();

$(document).on('click', '[data-crud-bookdetails]', function () {

    var bookName = $('[data-bookname]').val();
    var author = $('[data-author]').val();
    var description = $('[data-description]').val();
    var command = '';

    if (NTLibrary.IsValidValue($(this)[0].attributes['data-command'].textContent)) {
        command = $(this)[0].attributes['data-command'].textContent;
    }

    if (NTLibrary.IsValidValue(bookName) && NTLibrary.IsValidValue(author) && NTLibrary.IsValidValue(description)) {
        NTLibrary.GetBookDetails(bookName, author, description, command);
    }

});

$(document).on('click', '[data-admin-user]', function () {
    $('[data-admin-user]').addClass('current');
    $('[data-search]').removeClass('current');
    NTLibrary.GetAdminPage();
});

$(document).on('click', '[data-search]', function () {
    $('[data-admin-user]').removeClass('current');
    $('[data-search]').addClass('current');
    NTLibrary.GetHomePage();
});

$(document).on('keyup', '[data-bookname]', function () {
    setTimeout(function () {
        NTLibrary.ClearDataTableContent();
    }, 50);
    var Enteredvalue = $('[data-bookname]')[0].value;

    //if (NTLibrary.IsValidValue(Enteredvalue))
        NTLibrary.GetBookDetails($('[data-bookname]')[0].value);
});

$(document).on('click', '[data-manage]', function () {
    if (NTLibrary.IsValidValue($(this)[0].attributes['data-activity'].textContent)) {
        var section = $(this)[0].attributes['data-activity'].textContent;

        $('#processData').removeClass('hideit');

        switch (section) {
            case "delete":
                $('[data-manage-data]').addClass('hideit');
                break;
            default:
                $('[data-manage-data]').removeClass('hideit');
                break;
        }
    }
});

function ManageData() {

    var bookName = $('[data-addnew-name]').val();
    var author = $('[data-addnew-author]').val();
    var description = $('[data-addnew-description]').val();
    var command = $('input[name=activityRadio]:checked')[0].value;

    if (NTLibrary.IsValidValue(bookName) && NTLibrary.IsValidValue(author) && NTLibrary.IsValidValue(description)) {
        NTLibrary.ManipulateBookDetails(bookName, author, description, command);
    }
}

$(document).on('click', '[data-insertdata]', function () {
    var count = $('[data-count-insert]').val();
    if (NTLibrary.IsValidValue(count)) {
        NTLibrary.DumpBulkData(count);
    }
});

$(document).on('click', '[data-admin-dump]', function () {
   
    $('[data-search]').removeClass('current');
    $('[data-admin-user]').removeClass('current');
    $('[data-admin-dump]').addClass('current');
    NTLibrary.GetDataDumpPage();
});