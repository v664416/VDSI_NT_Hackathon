﻿"use strict"
var nameSpace = NTLibrary.createNamespace("NTLibrary.LibraryMgmt");

nameSpace.LibraryFunctions = function () {
    this.GetAdminPage = function () {
        var ServerURL = this.getRootUrl() + 'NTLibrary/GetAdminPage';
        window.location.href = ServerURL;
    };
    this.GetHomePage = function () {
        var ServerURL = this.getRootUrl() + 'NTLibrary/Home';;
        window.location.href = ServerURL;

    };

    this.ManipulateBookDetails = function (bookName, author, description, command) {
        switch (command) {
            case "ADD":
                this.CRUDBookDetails(bookName, author, description, 'CreateData');
                break;
            case "EDIT":
                this.CRUDBookDetails(bookName, author, description, 'UpdateData');
                break;
            case "DELETE":
                this.CRUDBookDetails(bookName, author, description, 'DeleteData');
                break;
            default:
                break;
        }
    };

    this.CRUDBookDetails = function (bookName, author, description, methodName) {

        var self = this;
        var bookDetails = {
            Id: 0,
            BookName: bookName,
            BookDesc: description,
            AuthorName: author
        };
        var ServerURL = self.getRootUrl() + 'NTLibrary/' + methodName;
        $.ajax({
            url: ServerURL,
            data: bookDetails,
            type: 'POST',
            //contentType: "application/json; charset=utf-8",
            //cache: false,
            success: function (data) {
                if (self.IsValidValue(data) && $.trim(data).toUpperCase() == "SUCCESS")
                    alert("Success");
            },
            error: function (data) {
                var i = 0;
            }
        });
    };

    this.GetBookDetails = function (bookName) {
        var self = this;
        //var bookDetails = {
        //    BookId: "",
        //    BookName: bookName,
        //    Author: author,
        //    Description: description,
        //    Command: command
        //};
        var ServerURL = self.getRootUrl() + 'NTLibrary/ManipulateBookDetails';
        $.ajax({
            url: ServerURL,
            data: { BookName: bookName },
            type: 'POST',
            //contentType: "application/json; charset=utf-8",
            //cache: false,
            success: function (data) {

                $('[data-elapseddata]')[0].textContent = data.elapsedTime;
                var columns = self.GetColumnTitlesAndData();
                var table = $("#tblBookDetails").DataTable({
                    "columns": columns.data,
                    "sDom": "frtis",                    
                    "info": false,
                    "bFilter": false,
                    "binfo": true,
                    "paging":false,
                    "bSortable": false,
                    "bDeferRender": true,
                    "scrollY": "500px",
                    "destroy":true,
                    "oScroller":{
                        "displayBuffer":10
                    },
                    "data": data.BookDetailsList
                });
                $("#AdminTasksRow").removeClass("hideit");

            },
            error: function (data) {
                var i = 0;
            }
        });
    };

    this.ClearDataTableContent = function () {
        var element = $("#tblBookDetails");
        if (this.IsValidValue(element[0]) && this.IsValidValue(element[0].innerHTML)) {
            if ($.fn.DataTable.fnIsDataTable(element)) {
                element.DataTable().destroy();
                element.html('');
            }
        }
    };

    this.GetColumnTitlesAndData = function () {
        var bookDetailsHeaders = ["Id", "BookName", "BookDesc", "AuthorName"];
        var title = this.GetTitles();
        var data = this.GetData();
        var result = {
            columns: [],
            data: []
        };
        for (var colIndex = 0; colIndex < bookDetailsHeaders.length; colIndex++) {
            result.data.push(new this.column(title[bookDetailsHeaders[colIndex]], data[bookDetailsHeaders[colIndex]], ""))
        }
        return result;
    }
    this.column = function (title, data, className) {
        this.title = title;
        this.data = data;
        this.className = className;
        return this;
    };

    this.GetTitles = function () {
        var title = {
            Id: "Book ID",
            BookName: "Book Name",
            BookDesc: "Description",
            AuthorName: "Author"
        }

        return title;
    };

    this.GetData = function () {
        var data = {
            Id: "Id",
            BookName: "BookName",
            BookDesc: "BookDesc",
            AuthorName: "AuthorName"
        }
        return data;
    };

    this.IsValidValue = function (value) {
        if (value != null && value != '' && value != undefined)
            return true;
        else
            return false;
    };

    this.DumpBulkData = function (count) {
        var ServerURL = this.getRootUrl() + 'NTLibrary/DataBookDetails';
        $.ajax({
            url: ServerURL,
            data: { count: count },
            type: 'POST',
            
            success: function (data) {
                if (data == 0)
                    alert("SUCCESS");
            },
            error: function (data) {
                alert(data);
            }
        });
    };

    this.getRootUrl = function () {
        return rootUrl;
        var defaultPorts = { "http:": 80, "https:": 443 };

        return window.location.protocol + "//" + window.location.hostname
         + (((window.location.port)
          && (window.location.port != defaultPorts[window.location.protocol]))
          ? (":" + window.location.port) : "");
    };

    this.GetDataDumpPage = function () {
        var ServerURL = this.getRootUrl() + 'NTLibrary/DataLoaderHome';;
        window.location.href = ServerURL;
    };

};


