﻿"use strict"
var NTLibrary = NTLibrary || {};

NTLibrary.createNamespace = function (namespace) {
    var nsparts = namespace.split('.');
    var parent = NTLibrary;

    if (nsparts[0] == "NTLibrary") {
        nsparts = nsparts.slice(1);
    }

    for (var i = 0; i < nsparts.length; i++) {
        var partname = nsparts[i];
        if (typeof parent[partname] == "undefined") {
            parent[partname] = {};
        }
        parent = parent[partname];
    }
    return parent;
};