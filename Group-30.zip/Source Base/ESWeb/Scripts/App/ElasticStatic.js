﻿"use strict";
var nameSpace = Elasticsearch.createNamespace("Elasticsearch.ElasticStatic");

nameSpace.ElasticStatic = function () {
    alert('test');

    $.ajax({
        url: "/Home/CreateBookDetails",
        type: "GET",
        dataType: 'json',
        success: function (response) {
            alert('s');
        }
    });
};

nameSpace.Searchdata = function () {
    alert('test');

    $.ajax({
        url: "/Home/getData?fn=A&ln=AutoBiography",
        type: "POST",
        dataType: 'json',
        success: function (response) {
            alert('s');
        },
        error: function(e){
            alert(e);
    }
    });
};