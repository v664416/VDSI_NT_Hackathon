﻿"use strict"
var Elasticsearch = Elasticsearch || {};

Elasticsearch.createNamespace = function (namespace) {
    var nsparts = namespace.split('.');
    var parent = Elasticsearch;

    if (nsparts[0] == "Elasticsearch") {
        nsparts = nsparts.slice(1);
    }

    for (var i = 0; i < nsparts.length; i++) {
        var partname = nsparts[i];
        if (typeof parent[partname] == "undefined") {
            parent[partname] = {};
        }
        parent = parent[partname];
    }
    return parent;
};