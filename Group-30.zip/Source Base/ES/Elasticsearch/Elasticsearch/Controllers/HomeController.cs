﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nest;
using ElasticsearchCRUD;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Elasticsearch.Controllers
{
    public class HomeController : Controller
    {
        private const string ConnectionString = "http://localhost:9200/";
        private readonly IElasticsearchMappingResolver _elasticsearchMappingResolver = new ElasticsearchMappingResolver();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult getElastic()
        {
            ViewBag.Message = "Elastic Search.";



            return View("ElasticSearch");
        }




        public string CreateBookDetails()
        {
            

            var node = new Uri("http://localhost:9200");

            var settings = new ConnectionSettings(
                node,
                defaultIndex: "bookinfo"

            );

            var client = new ElasticClient(settings);

            string text1 = System.IO.File.ReadAllText(@"D:/Source Base\XML.txt");
            for (int i = 0; i < text1.Split('@').Length; i++)
            {
                BookData book = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<BookData>(text1.Split('@')[i]);
                var index = client.Index(book);
            }
            //for (int i = 0; i < 100; i++)
            //{
            //    var book = new BookData
            // {
            //     Id = i,
            //     BookName = "Gandiji" + i,
            //     BookDesc = "AutoBiography"
            // };
            //    var index = client.Index(book);
            //    // index = client.CreateIndex("book", c => c.AddMapping<BookData>(m => m.MapFromAttributes()));
            //}



            return "0";
        }
        public class BookData
        {
            public int Id { get; set; }
            public string BookName { get; set; }
            public string BookDesc { get; set; }
            public string AuthorName { get; set; }
            public string Link  {get; set; }
 
        }


        public JsonResult getData(string fn, string ln)
        {

            var node = new Uri("http://localhost:9200");

            var settings = new ConnectionSettings(
                node,
                defaultIndex: "bookinfo"
            );

            var client = new ElasticClient(settings);

                //Search
                var result = client.Search<BookData>(body =>
        body.Query(query =>
            query.ConstantScore(
                csq => csq.Filter(filter =>
                    filter.Prefix(x =>
                        x.BookName, fn.ToLower()))))
        .Take(1000));

                    //Delete
                    client.DeleteByQuery<BookData>(q => q
            .Query(rq => rq
                .Term(f => f.Id, 10)
            )
        );


                    //Update record on index 5
                    client.Update<BookData, object>(u => u
            .Id(5)
            .Doc(new { BookName = "Angular JS" })
            .RetryOnConflict(3)
            .Refresh()
        );



            long count = result.Total;
            return Json(result.Documents);
        }

    }

}







