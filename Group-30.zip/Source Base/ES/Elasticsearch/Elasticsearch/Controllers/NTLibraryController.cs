﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nest;
using ElasticsearchCRUD;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using Elasticsearch.Models;


namespace LibraryMgmt.Controllers
{
    public class NTLibraryController : Controller
    {
        private const string ConnectionString = "http://localhost:9200/";
        private readonly IElasticsearchMappingResolver _elasticsearchMappingResolver = new ElasticsearchMappingResolver();

        public ActionResult Home()
        {
            BookDetailsModel bookDetailsList = new BookDetailsModel();
            return View("~/Views/NTLibrary/Home.cshtml", bookDetailsList);
        }
        public ActionResult GetAdminPage()
        {
            BookDetailsModel bookDetailsList = new BookDetailsModel();
            return View("~/Views/NTLibrary/AdminHome.cshtml", bookDetailsList);
        }

        public ActionResult DataLoaderHome()
        {            
            return View("~/Views/NTLibrary/DataLoaderHome.cshtml");
        }

        [HttpPost]
        public JsonResult ManipulateBookDetails(string BookName)//BookDetails bookDetails)
        {
            //for (int i = 0; i < 25; i++)
            //{
            //    int count = 10000;
            //    DataDumpBookDetails(i);
            //    count = count + 10000;
            //}
           // DataDumpBookDetails(count);
            return ReadData(BookName);
        }
        public string CreateData(BookData book)
        {
            var node = new Uri("http://localhost:9200");

            var settings = new ConnectionSettings(
                node,
                defaultIndex: "bookdetail"
            );

            var client = new ElasticClient(settings);
            var index = client.Index(book);


            return "";
        }
       
        public JsonResult ReadData(string bookName)
        {

            var node = new Uri("http://localhost:9200");

            var settings = new ConnectionSettings(
                node,
                defaultIndex: "bookdetail"
            );

            var client = new ElasticClient(settings);

            //Search
            //var result = client.Search<BookData>(body =>
            //    body.Query(query =>
            //        query.ConstantScore(
            //            csq => csq.Filter(filter =>
            //                filter.Prefix(x =>
            //                    x.BookName, bookName.ToLower()))))
            //    .Take(1000));

            var result = client.Search<BookData>(body =>
               body.Query(query =>
                   query.ConstantScore(
                       csq => csq.Filter(filter =>
                           filter.Regexp(x =>
                                x.OnField("bookName").Value(".*" + bookName.ToLower() + ".*"))))).Take(1000));
              

            long count = result.Total;
            BookDetailsModel resultSet = new BookDetailsModel();
            resultSet.BookDetailsList = result.Documents;
            resultSet.elapsedTime = result.Total.ToString() + " records in " + (Convert.ToDouble(result.ElapsedMilliseconds) / 1000).ToString("0.0000") + " seconds.";
            return Json(resultSet);
        }
        
        public string UpdateData(BookData book)
        {
            var node = new Uri("http://localhost:9200");

            var settings = new ConnectionSettings(
                node,
                defaultIndex: "bookdetail"
            );

            var client = new ElasticClient(settings);

            //Update record on index 5
                        client.Update<BookData, object>(u => u
                .Id(book.Id)
                .Doc(new { BookName = book.BookName })
                .RetryOnConflict(3)
                .Refresh()
            );
            return "";
        }

        public string DeleteData(BookData book)
        {

            var node = new Uri("http://localhost:9200");

            var settings = new ConnectionSettings(
                node,
                defaultIndex: "bookdetail"
            );

            var client = new ElasticClient(settings);

            //Delete
            client.DeleteByQuery<BookData>(q => q
                        .Query(rq => rq
                            .Term(f => f.Id, book.Id)
                        )
                    );
            return "";
        }

        public string DataDumpBookDetails(int count)
        {


            var node = new Uri("http://localhost:9200");

            var settings = new ConnectionSettings(
                node,
                defaultIndex: "bookdetail"

            );

            var client = new ElasticClient(settings);

            string text1 = System.IO.File.ReadAllText(@"D:/Source Base\XML.txt");
            for (int i = 0; i < text1.Split('@').Length; i++)
            {
                BookData book = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<BookData>(text1.Split('@')[i]);
                if (book != null)
                {
                    BookData book1 = book;
                    book1.Id = book.Id + count;


                    var index = client.Index(book1);
                }
            }
            //for (int i = 0; i < 100; i++)
            //{
            //    var book = new BookData
            // {
            //     Id = i,
            //     BookName = "Gandiji" + i,
            //     BookDesc = "AutoBiography"
            // };
            //    var index = client.Index(book);
            //    // index = client.CreateIndex("book", c => c.AddMapping<BookData>(m => m.MapFromAttributes()));
            //}



            return "0";
        }

        [HttpPost]
        public int DataBookDetails(int count)//BookDetails bookDetails)
        {
            try
            {
                for (int i = 0; i < 25; i++)
                {
                    DataDumpBookDetails(count);
                    count = count+10000; 
                }
            }
            catch (Exception)
            {
                
                throw;
            }
           
            //DataDumpBookDetails(count);
            return 0;
        }
    }
}