﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Elasticsearch.Models
{
    public class BookData
    {
        public int Id { get; set; }
        public string BookName { get; set; }
        public string BookDesc { get; set; }
        public string AuthorName { get; set; }
        //public string Link { get; set; }

    }

    public class BookDetailsModel
    {
        public object BookDetailsList { get; set; }
        public string elapsedTime { get; set; }
    }
}