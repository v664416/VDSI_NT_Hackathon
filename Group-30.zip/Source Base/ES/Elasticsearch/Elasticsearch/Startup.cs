﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Elasticsearch.Startup))]
namespace Elasticsearch
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
